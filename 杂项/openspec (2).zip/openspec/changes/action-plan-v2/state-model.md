# ActionPlan V2 — 状态模型

> 核心公式：`state + event → newState → view`

## State Shape

```typescript
// ── View enum ──
type ActionPlanView = "today" | "gantt" | "chain";

// ── Server State ── （来自后端 API）
interface ActionPlanTask {
  id: string;
  title: string;
  date: string;                   // "YYYY-MM-DD"
  estimatedMinutes: number;
  done: boolean;
  note: string;
  x: number | null;               // chain view position
  y: number | null;
}

interface ActionPlan {
  id: string;
  title: string;
  planType: string;
  description: string;
  startDate: string;
  endDate: string;
  dailyAvailableTime: string;
  priority: "低" | "普通" | "高";
  status: "未开始" | "进行中" | "暂停" | "已完成" | "放弃";
  sourceLightPlanId: string;
  tasks: ActionPlanTask[];
  summary: string;
  createdAt: string;
  updatedAt: string;
}

// ── UI State ──
interface ActionPlanState {
  // 列表
  plans: ActionPlan[];
  selectedPlanId: string | null;
  query: string;
  statusFilter: string;            // "全部" | status value
  loading: boolean;
  saving: boolean;
  error: string | null;

  // 视图
  currentView: ActionPlanView;

  // 任务选择
  selectedTaskId: string | null;

  // 弹窗
  planEditorOpen: boolean;
  taskEditorOpen: boolean;
  deleteConfirmTarget: { type: "plan" | "task"; id: string } | null;

  // AI 拆解
  aiBreakdownDialogOpen: boolean;
  aiBreakdownParams: { startDate: string; endDate: string; dailyTime: string };
  aiLoading: boolean;
  aiDraft: {                        // AI 返回的草稿
    title: string;
    planType: string;
    tasks: { date: string; title: string; estimatedMinutes: number; note: string }[];
  } | null;
  aiPreviewOpen: boolean;
  aiRawResponse: string | null;     // 非法 JSON 时展示
}

// ── Derived State ── （由 reducer 计算，不单独存储）
// selectedPlan:        plans.find(p => p.id === selectedPlanId)
// selectedTask:        selectedPlan?.tasks.find(t => t.id === selectedTaskId)
// progress:            doneCount / totalCount * 100 (0 when no tasks)
// groupedByDate:       selectedPlan?.tasks grouped by date
// todayTasks:          selectedPlan?.tasks where date === today && !done
// overdueTasks:        selectedPlan?.tasks where date < today && !done
// remainingCount:      totalCount - doneCount
// isOnTodayView:       currentView === "today"
// isOnGanttView:       currentView === "gantt"
// isOnChainView:       currentView === "chain"
```

## Events

```typescript
type ActionPlanEvent =
  // 初始化 & 加载
  | { type: "INIT_PAGE" }
  | { type: "LOAD_SUCCESS"; plans: ActionPlan[] }
  | { type: "LOAD_FAILED"; message: string }

  // 列表
  | { type: "SELECT_PLAN"; planId: string }
  | { type: "CHANGE_QUERY"; query: string }
  | { type: "CHANGE_STATUS_FILTER"; filter: string }
  | { type: "NEW_PLAN" }
  | { type: "DELETE_PLAN_REQUEST"; planId: string }
  | { type: "DELETE_PLAN_CONFIRM" }
  | { type: "DELETE_PLAN_CANCEL" }
  | { type: "DELETE_PLAN_SUCCESS"; planId: string }
  | { type: "DELETE_PLAN_FAILED"; message: string }

  // 视图
  | { type: "SWITCH_VIEW"; view: ActionPlanView }

  // 计划编辑
  | { type: "OPEN_PLAN_EDITOR" }
  | { type: "CLOSE_PLAN_EDITOR" }
  | { type: "SAVE_PLAN_REQUEST"; plan: Partial<ActionPlan> }
  | { type: "SAVE_PLAN_SUCCESS"; plan: ActionPlan }
  | { type: "SAVE_PLAN_FAILED"; message: string }

  // 任务选择 & 勾选
  | { type: "SELECT_TASK"; taskId: string | null }
  | { type: "TOGGLE_TASK_DONE"; taskId: string; done: boolean }

  // 任务编辑
  | { type: "OPEN_TASK_EDITOR"; taskId: string | null }
  | { type: "CLOSE_TASK_EDITOR" }
  | { type: "SAVE_TASK_REQUEST"; task: Partial<ActionPlanTask> }
  | { type: "SAVE_TASK_SUCCESS"; task: ActionPlanTask }
  | { type: "SAVE_TASK_FAILED"; message: string }
  | { type: "DELETE_TASK_REQUEST"; taskId: string }
  | { type: "DELETE_TASK_CONFIRM" }
  | { type: "DELETE_TASK_CANCEL" }

  // 甘特图拖拽
  | { type: "MOVE_TASK_ON_GANTT"; taskId: string; newDate: string }

  // 任务链拖拽
  | { type: "MOVE_NODE_ON_CHAIN"; taskId: string; x: number; y: number }

  // AI 拆解
  | { type: "OPEN_AI_BREAKDOWN" }
  | { type: "CLOSE_AI_BREAKDOWN" }
  | { type: "UPDATE_AI_BREAKDOWN_PARAMS"; params: Partial<{ startDate: string; endDate: string; dailyTime: string }> }
  | { type: "SUBMIT_AI_BREAKDOWN" }
  | { type: "RECEIVE_AI_DRAFT"; draft: { title: string; planType: string; tasks: any[] }; raw: string }
  | { type: "AI_RESPONSE_INVALID"; raw: string; message: string }
  | { type: "AI_FAILED"; message: string }
  | { type: "APPLY_AI_DRAFT" }
  | { type: "CANCEL_AI_DRAFT" };
```

## Transition Table

### 初始化 & 加载

| Current State | Event | Condition | New State | View Update |
|---|---|---|---|---|
| loading=false | INIT_PAGE | 无 | loading=true, error=null | 全页 loading spinner |
| loading=true | LOAD_SUCCESS(plans) | plans.length>0 | plans=event.plans, loading=false, selectedPlanId=plans[0].id | 左侧列表填充，右侧显示第一个计划的 today 视图 |
| loading=true | LOAD_SUCCESS([]) | 空 | plans=[], loading=false, selectedPlanId=null | 空状态引导 |
| loading=true | LOAD_FAILED(msg) | 无 | loading=false, error=msg | 错误提示，不阻隔页面 |

### 列表操作

| Current State | Event | Condition | New State | View Update |
|---|---|---|---|---|
| selectedPlanId=p1 | SELECT_PLAN(p2) | p2 ≠ p1 | selectedPlanId=p2, selectedTaskId=null, currentView="today" | 左侧高亮切换，右侧刷新为 p2 |
| selectedPlanId=p1 | SELECT_PLAN(p1) | 无变化 | 不变 | 无反应 |
| selectedPlanId≠null | DELETE_PLAN_REQUEST(id) | 无 | deleteConfirmTarget={type:"plan", id} | 显示删除确认弹窗 |
| deleteConfirmTarget≠null | DELETE_PLAN_CONFIRM | 无 | deleteConfirmTarget=null, saving=true | 执行删除 effect |
| saving=true | DELETE_PLAN_SUCCESS(id) | id===selectedPlanId | selectedPlanId=plans[0]?.id||null, plans 过滤 | 列表移除，右侧切换 |
| saving=true | DELETE_PLAN_SUCCESS(id) | id≠selectedPlanId | plans 过滤 | 列表仅移除该项 |
| saving=true | DELETE_PLAN_FAILED(msg) | 无 | saving=false, error=msg | 错误提示 |
| 任意 | CHANGE_QUERY(q) | 无 | query=q | 列表重新过滤 |
| 任意 | CHANGE_STATUS_FILTER(f) | 无 | statusFilter=f | 列表重新过滤 |

### 视图切换

| Current State | Event | Condition | New State | View Update |
|---|---|---|---|---|
| selectedPlanId≠null, currentView="today" | SWITCH_VIEW("gantt") | 无 | currentView="gantt", selectedTaskId=null | 右侧从时间表切换为甘特图 |
| selectedPlanId≠null, currentView="gantt" | SWITCH_VIEW("chain") | 无 | currentView="chain" | 右侧从甘特图切换为任务链 |
| selectedPlanId=null | SWITCH_VIEW(任意) | 无 | 不变 | 无变化，可显示 toast "请先选择计划" |

### 任务勾选

| Current State | Event | Condition | New State | View Update |
|---|---|---|---|---|
| selectedPlan.tasks[t] | TOGGLE_TASK_DONE(t, true) | 无 | tasks[t].done=true, saving=true | 任务样式变灰+删除线，进度条增加，今日待办-1 |
| saving=true | SAVE_PLAN_SUCCESS | 无 | saving=false | 保存成功 |
| 同上 | TOGGLE_TASK_DONE(t, false) | 无 | tasks[t].done=false, saving=true | 任务还原，进度条减少 |

### 任务编辑（弹窗）

| Current State | Event | Condition | New State | View Update |
|---|---|---|---|---|
| selectedPlanId≠null | OPEN_TASK_EDITOR(null) | 无 | taskEditorOpen=true | 弹出新建任务弹窗（空白） |
| selectedTaskId≠null | OPEN_TASK_EDITOR(id) | 无 | taskEditorOpen=true | 弹出编辑任务弹窗（预填） |
| taskEditorOpen=true | SAVE_TASK_REQUEST(newTask) | 无 | taskEditorOpen=false, saving=true | 关闭弹窗，执行保存 effect |
| saving=true | SAVE_TASK_SUCCESS(task) | task.id 已存在 | tasks 替换对应项 | 视图更新 |
| saving=true | SAVE_TASK_SUCCESS(task) | task.id 不存在 | tasks 追加新项 | 视图更新 |
| taskEditorOpen=true | CLOSE_TASK_EDITOR | 无 | taskEditorOpen=false | 关闭弹窗，不保存 |

### 甘特图拖拽

| Current State | Event | Condition | New State | View Update |
|---|---|---|---|---|
| currentView="gantt" | MOVE_TASK_ON_GANTT(t, newDate) | 无 | tasks[t].date=newDate | 任务条移动到新日期列 |
| — | (debounce 500ms) | 无 | saving=true → SAVE_PLAN_SUCCESS | 自动保存 |

### 任务链拖拽

| Current State | Event | Condition | New State | View Update |
|---|---|---|---|---|
| currentView="chain" | MOVE_NODE_ON_CHAIN(t, x, y) | 无 | tasks[t].x=x, tasks[t].y=y | 节点移动到新位置，线重绘 |
| — | (debounce 500ms) | 无 | saving=true → SAVE_PLAN_SUCCESS | 坐标自动保存 |

### AI 拆解

| Current State | Event | Condition | New State | View Update |
|---|---|---|---|---|
| selectedPlanId≠null | OPEN_AI_BREAKDOWN | 无 | aiBreakdownDialogOpen=true | 弹出时间设置弹窗 |
| aiBreakdownDialogOpen=true | UPDATE_AI_BREAKDOWN_PARAMS(p) | 无 | aiBreakdownParams={...params, ...p} | 表单实时更新 |
| aiBreakdownDialogOpen=true | SUBMIT_AI_BREAKDOWN | 日期合法 | aiBreakdownDialogOpen=false, aiLoading=true | 显示 AI 加载中 |
| aiLoading=true | CLOSE_AI_BREAKDOWN | 无 | 同 SUBMIT 或恢复 | 关闭 |
| aiLoading=true | RECEIVE_AI_DRAFT(draft, raw) | JSON 合法 | aiLoading=false, aiDraft=draft, aiPreviewOpen=true | 弹出 AI 预览弹窗 |
| aiLoading=true | AI_RESPONSE_INVALID(raw, msg) | 非法 JSON | aiLoading=false, error=msg, aiRawResponse=raw | 显示错误 + "查看原始返回" |
| aiLoading=true | AI_FAILED(msg) | 无 | aiLoading=false, error=msg | 显示错误 |
| aiPreviewOpen=true | APPLY_AI_DRAFT | 无 | aiPreviewOpen=false, aiDraft=null, plans 替换 tasks 和 title | 视图更新为新任务列表 |
| aiPreviewOpen=true | CANCEL_AI_DRAFT | 无 | aiPreviewOpen=false, aiDraft=null | 关闭，无变化 |

## Reducer Pseudocode

```typescript
function actionPlanReducer(state: ActionPlanState, event: ActionPlanEvent): ActionPlanState {
  switch (event.type) {
    // ── 初始化 & 加载 ──
    case "INIT_PAGE":
      return { ...state, loading: true, error: null };

    case "LOAD_SUCCESS":
      const plans = event.plans;
      return {
        ...state,
        loading: false,
        error: null,
        plans,
        selectedPlanId: plans.length > 0 ? plans[0].id : null,
        currentView: "today",
        selectedTaskId: null,
      };

    case "LOAD_FAILED":
      return { ...state, loading: false, error: event.message };

    // ── 列表 ──
    case "SELECT_PLAN":
      if (event.planId === state.selectedPlanId) return state;
      const p = state.plans.find(p => p.id === event.planId);
      return {
        ...state,
        selectedPlanId: event.planId,
        selectedTaskId: null,
        currentView: "today",
        error: null,
      };

    case "DELETE_PLAN_REQUEST":
      return { ...state, deleteConfirmTarget: { type: "plan", id: event.planId } };

    case "DELETE_PLAN_CONFIRM":
      return { ...state, deleteConfirmTarget: null, saving: true };

    case "DELETE_PLAN_CANCEL":
      return { ...state, deleteConfirmTarget: null };

    case "DELETE_PLAN_SUCCESS": {
      const remaining = state.plans.filter(p => p.id !== event.planId);
      return {
        ...state,
        saving: false,
        plans: remaining,
        selectedPlanId: remaining.length > 0 ? remaining[0].id : null,
        selectedTaskId: null,
        currentView: "today",
      };
    }

    case "DELETE_PLAN_FAILED":
      return { ...state, saving: false, error: event.message };

    case "CHANGE_QUERY":
      return { ...state, query: event.query };

    case "CHANGE_STATUS_FILTER":
      return { ...state, statusFilter: event.filter };

    // ── 视图 ──
    case "SWITCH_VIEW":
      if (state.selectedPlanId === null) return state;
      return { ...state, currentView: event.view, selectedTaskId: null };

    // ── 计划编辑 ──
    case "OPEN_PLAN_EDITOR":
      return { ...state, planEditorOpen: true };

    case "CLOSE_PLAN_EDITOR":
      return { ...state, planEditorOpen: false };

    case "SAVE_PLAN_REQUEST":
      return { ...state, planEditorOpen: false, saving: true };

    case "SAVE_PLAN_SUCCESS": {
      const i = state.plans.findIndex(p => p.id === event.plan.id);
      const plans = i >= 0
        ? state.plans.map((p, idx) => idx === i ? event.plan : p)
        : [...state.plans, event.plan];
      return {
        ...state,
        saving: false,
        plans,
        selectedPlanId: event.plan.id,
      };
    }

    case "SAVE_PLAN_FAILED":
      return { ...state, saving: false, error: event.message };

    // ── 任务操作 ──
    case "SELECT_TASK":
      return { ...state, selectedTaskId: event.taskId };

    case "TOGGLE_TASK_DONE": {
      const plan = state.plans.find(p => p.id === state.selectedPlanId);
      if (!plan) return state;
      const tasks = plan.tasks.map(t =>
        t.id === event.taskId ? { ...t, done: event.done } : t
      );
      return updateTasks(state, tasks);
    }

    case "OPEN_TASK_EDITOR":
      return { ...state, taskEditorOpen: true };

    case "CLOSE_TASK_EDITOR":
      return { ...state, taskEditorOpen: false };

    case "SAVE_TASK_REQUEST":
      return { ...state, taskEditorOpen: false, saving: true };

    case "SAVE_TASK_SUCCESS": {
      const p = state.plans.find(p => p.id === state.selectedPlanId);
      if (!p) return { ...state, saving: false };
      const existing = p.tasks.some(t => t.id === event.task.id);
      const tasks = existing
        ? p.tasks.map(t => t.id === event.task.id ? event.task : t)
        : [...p.tasks, event.task];
      return { ...updateTasks(state, tasks), saving: false };
    }

    case "SAVE_TASK_FAILED":
      return { ...state, saving: false, error: event.message };

    case "DELETE_TASK_REQUEST":
      return { ...state, deleteConfirmTarget: { type: "task", id: event.taskId } };

    case "DELETE_TASK_CONFIRM": {
      if (!state.deleteConfirmTarget) return state;
      const plan = state.plans.find(p => p.id === state.selectedPlanId);
      if (!plan) return { ...state, deleteConfirmTarget: null };
      const tasks = plan.tasks.filter(t => t.id !== state.deleteConfirmTarget.id);
      return { ...updateTasks(state, tasks), deleteConfirmTarget: null, selectedTaskId: null };
    }

    case "DELETE_TASK_CANCEL":
      return { ...state, deleteConfirmTarget: null };

    // ── 甘特图拖拽 ──
    case "MOVE_TASK_ON_GANTT": {
      const plan = state.plans.find(p => p.id === state.selectedPlanId);
      if (!plan) return state;
      const tasks = plan.tasks.map(t =>
        t.id === event.taskId ? { ...t, date: event.newDate } : t
      );
      return updateTasks(state, tasks);
    }

    // ── 任务链拖拽 ──
    case "MOVE_NODE_ON_CHAIN": {
      const plan = state.plans.find(p => p.id === state.selectedPlanId);
      if (!plan) return state;
      const tasks = plan.tasks.map(t =>
        t.id === event.taskId ? { ...t, x: event.x, y: event.y } : t
      );
      return updateTasks(state, tasks);
    }

    // ── AI 拆解 ──
    case "OPEN_AI_BREAKDOWN":
      return {
        ...state,
        aiBreakdownDialogOpen: true,
        aiBreakdownParams: {
          startDate: todayISO(),
          endDate: addDays(todayISO(), 7),
          dailyTime: "",
        },
        aiError: null,
      };

    case "CLOSE_AI_BREAKDOWN":
      return { ...state, aiBreakdownDialogOpen: false };

    case "UPDATE_AI_BREAKDOWN_PARAMS":
      return {
        ...state,
        aiBreakdownParams: { ...state.aiBreakdownParams, ...event.params },
      };

    case "SUBMIT_AI_BREAKDOWN":
      return { ...state, aiBreakdownDialogOpen: false, aiLoading: true, aiError: null };

    case "RECEIVE_AI_DRAFT":
      return {
        ...state,
        aiLoading: false,
        aiDraft: event.draft,
        aiRawResponse: null,
        aiPreviewOpen: true,
      };

    case "AI_RESPONSE_INVALID":
      return {
        ...state,
        aiLoading: false,
        aiError: event.message,
        aiRawResponse: event.raw,
        aiPreviewOpen: true,  // 在预览弹窗中显示错误 + 原始返回
      };

    case "AI_FAILED":
      return { ...state, aiLoading: false, aiError: event.message };

    case "APPLY_AI_DRAFT": {
      if (!state.aiDraft || !state.selectedPlanId) return state;
      const plan = state.plans.find(p => p.id === state.selectedPlanId);
      if (!plan) return { ...state, aiPreviewOpen: false, aiDraft: null };
      const newPlan = {
        ...plan,
        title: state.aiDraft.title,
        planType: state.aiDraft.planType,
        tasks: state.aiDraft.tasks.map((t, i) => ({
          id: generateId(),
          title: t.title,
          date: t.date,
          estimatedMinutes: t.estimatedMinutes,
          done: false,
          note: t.note || "",
          x: null,
          y: null,
        })),
      };
      return {
        ...state,
        aiPreviewOpen: false,
        aiDraft: null,
        plans: state.plans.map(p => p.id === state.selectedPlanId ? newPlan : p),
        selectedTaskId: null,
        currentView: "today",
      };
    }

    case "CANCEL_AI_DRAFT":
      return { ...state, aiPreviewOpen: false, aiDraft: null, aiRawResponse: null };

    default:
      return state;
  }
}

// Helper: 更新当前计划的 tasks 列表
function updateTasks(state: ActionPlanState, tasks: ActionPlanTask[]): ActionPlanState {
  return {
    ...state,
    plans: state.plans.map(p =>
      p.id === state.selectedPlanId ? { ...p, tasks } : p
    ),
    saving: true,
  };
}
```

## Effects

| Trigger Event | Effect | Success Event | Failure Event |
|---|---|---|---|
| INIT_PAGE | fetch GET /api/modules/action_plans | LOAD_SUCCESS | LOAD_FAILED |
| SAVE_PLAN_REQUEST | PUT /api/modules/action_plans (full plan) | SAVE_PLAN_SUCCESS | SAVE_PLAN_FAILED |
| DELETE_PLAN_CONFIRM | DELETE /api/modules/action_plans/:id | DELETE_PLAN_SUCCESS | DELETE_PLAN_FAILED |
| TOGGLE_TASK_DONE | PUT /api/modules/action_plans (tasks update) | SAVE_PLAN_SUCCESS | SAVE_PLAN_FAILED |
| SAVE_TASK_REQUEST | PUT /api/modules/action_plans (tasks update) | SAVE_TASK_SUCCESS | SAVE_TASK_FAILED |
| DELETE_TASK_CONFIRM | PUT /api/modules/action_plans (tasks filter) | SAVE_PLAN_SUCCESS | SAVE_PLAN_FAILED |
| MOVE_TASK_ON_GANTT | debounce 500ms → PUT (date update) | SAVE_PLAN_SUCCESS | SAVE_PLAN_FAILED |
| MOVE_NODE_ON_CHAIN | debounce 500ms → PUT (x/y update) | SAVE_PLAN_SUCCESS | SAVE_PLAN_FAILED |
| SUBMIT_AI_BREAKDOWN | POST to AI backend /api/ai/breakdown | RECEIVE_AI_DRAFT | AI_FAILED |
| APPLY_AI_DRAFT | PUT /api/modules/action_plans (full after apply) | SAVE_PLAN_SUCCESS | SAVE_PLAN_FAILED |

## View Mapping

| State Condition | View Behavior |
|---|---|
| loading=true | 全页居中 loading spinner |
| loading=false, plans.length=0, error=null | 空状态插画 + "新建第一个行动计划"按钮 |
| error!=null | 顶部错误条（可关闭），下方保留上次正常数据 |
| selectedPlanId=null | 右侧显示"请从左侧选择一个行动计划" |
| selectedPlanId≠null | 右侧头部显示：标题 / 类型 / 状态 / 进度条 |
| currentView="today" | 任务按日期分组展示，每个分组一个卡片 |
| currentView="gantt" | 时间横轴 + 每行一个任务 + 可拖拽条 |
| currentView="chain" | 深色背景画布 + 圆形节点 + 连线 |
| selectedTaskId≠null + currentView="chain" | 对应节点高亮边框 |
| planEditorOpen=true | 模态弹窗，包含计划所有编辑字段 |
| taskEditorOpen=true | 模态弹窗，包含任务所有编辑字段 |
| deleteConfirmTarget≠null | 删除确认弹窗 |
| aiBreakdownDialogOpen=true | 日期设置小弹窗 |
| aiLoading=true | AI 加载指示器（覆盖或行内） |
| aiPreviewOpen=true | AI 预览弹窗（只读 + 应用/取消） |
| aiRawResponse!=null | 预览弹窗中显示原始返回文本 |
| selectedPlan.tasks.length=0 | "还没有任务，点击"添加任务"开始" |
| overdueTasks.length>0 | 头部显示逾期警告 "N 个任务已逾期" |
| progress=100 && tasks.length>0 | 进度条显示 "全部完成" |

## Invariants

1. `selectedTaskId` 必须属于 `selectedPlanId` 对应的计划。如果计划被删除，selectedTaskId 必须置 null。
2. `currentView` 只能是 "today" | "gantt" | "chain" 三者之一。
3. AI 结果（aiDraft）不能直接写入 plans，必须先进入 aiPreviewOpen 状态。
4. 删除记录必须先设置 deleteConfirmTarget，用户确认后才能执行删除。
5. 任务勾选后必须同步到状态并触发保存，ui 不能先于保存生效。
6. 甘特图和任务链的拖拽必须在 debounce 后才保存，不能每次 pixel 移动都请求。
7. 视图切换不触发 API 调用，不修改服务器状态。
8. 任务日期移动后必须在对应视图中立即反映（乐观更新）。
9. `saving=true` 时所有操作按钮（保存/删除/AI）应禁用。
10. 非法 JSON 不崩溃，展示原始返回。

## Edge Cases

| 场景 | 处理 |
|---|---|
| 列表为空 | 空状态 + "新建"按钮 |
| 当前选中计划被删除 | 回退到 plans[0] 或 null |
| 后端加载失败 | 显示错误 + 保留上次数据 |
| AI 返回非法 JSON | 显示错误 + 原始返回文本 |
| 用户关闭编辑弹窗但未保存 | 无需确认（弹窗不做 draft 暂存，保存才确认） |
| 任务无 end_date | 甘特图中任务条宽度使用 estimatedMinutes 按比例 |
| 任务链节点无 x/y | 按日期和索引自动布局 |
| 旧数据缺少字段 | ActionPlanTask.from_dict 提供默认值 |
| 计划有 0 个任务 | 进度 0%，显示 "还没有任务" |
| 所有任务已完成 | 进度 100%，进度条显示 "全部完成！" |
| 今日待办为 0 | 显示 "今天没有待办任务" |
| 甘特图拖拽到过去 | 允许，但日期变为橙色标记 |
| 任务链节点拖出可视区 | 限制 scene rect 或允许滚动 |
| 多个计划有同名任务 | 通过 id 区分，无冲突 |
| 快速连续切换视图 | 不触发 API，纯状态切换，无冲突 |
