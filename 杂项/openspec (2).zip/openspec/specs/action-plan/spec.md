# Action Plan — 系统规格

> 状态：**设计中**

## Overview

行动计划是轻计划的执行层。轻计划回答"我想做什么"，行动计划回答"我什么时候做、做到哪了"。一个行动计划包含一组按日期排列的子任务。

## Data Model

```typescript
interface ActionPlan {
  id: string;
  title: string;
  planType: string;              // 学习 | 接单 | 项目 | 生活 | 身体 | 武术 | 情绪 | 长期目标 | 其他
  description: string;
  startDate: string;             // "YYYY-MM-DD"
  endDate: string;
  dailyAvailableTime: string;
  priority: string;              // 低 | 普通 | 高
  status: string;                // 未开始 | 进行中 | 暂停 | 已完成 | 放弃
  sourceLightPlanId: string;     // 来源轻计划 ID（可为空）
  tasks: ActionPlanTask[];
  summary: string;
  createdAt: string;
  updatedAt: string;
}

interface ActionPlanTask {
  id: string;
  title: string;
  date: string;                  // "YYYY-MM-DD"
  estimatedMinutes: number;
  done: boolean;
  note: string;
  x?: number | null;             // 任务链坐标
  y?: number | null;
}
```

## Storage

- 路径：`data/Diary/action_plans/<uuid>/action_plan.json`
- 使用 `ActionPlanStorage`（`src/life_dairy/action_plan_storage.py`）
- 软删除：与所有模块一致

## Requirement: Action Plan List

**R1**: 用户可以看到全部行动计划的列表。
- Scenario: 打开 ActionPlan 页面，左侧显示计划列表，每个条目显示标题、类型、状态、进度百分比。
- Scenario: 空数据时显示空状态引导。
- Scenario: 搜索按标题/描述/任务匹配。
- Scenario: 可按状态筛选（全部/未开始/进行中/暂停/已完成/放弃）。

## Requirement: Three Views

**R2**: 用户可以在三种视图间切换查看当前计划的子任务。

**R2.1 Today View（时间表）**
- Scenario: 子任务按日期分组显示。
- Scenario: 每个任务显示标题、预计耗时、备注。
- Scenario: 可勾选完成。
- Scenario: 勾选后进度条自动更新。
- Scenario: 已完成任务有明确视觉区分（删除线或颜色淡化）。
- Scenario: 日期分组标注"今天"和"逾期"。
- Scenario: 逾期任务有警告标识。

**R2.2 Gantt View（甘特图）**
- Scenario: 任务在时间横轴上按日期分布。
- Scenario: 每个任务显示为横向长条，位置对应日期。
- Scenario: 已完成任务颜色变化。
- Scenario: 可左右拖动调整任务日期。
- Scenario: 拖拽后自动保存新日期。

**R2.3 Chain View（任务链）**
- Scenario: 深色背景画布。
- Scenario: 每个日期是一条纵向主链。
- Scenario: 每个任务是一个可拖动的圆形节点。
- Scenario: 同一日期的节点在同一纵列上排列。
- Scenario: 节点间用线连接。
- Scenario: 已完成节点变为亮色。
- Scenario: 悬停显示任务信息（标题/日期/耗时）。
- Scenario: 双击节点打开任务编辑弹窗。
- Scenario: 拖动后保存坐标（x/y）。

## Requirement: Task CRUD

**R3**: 用户可以在当前计划下管理子任务。
- Scenario: 添加任务（弹窗输入标题/日期/耗时/备注）。
- Scenario: 编辑任务（弹窗）。
- Scenario: 删除任务（确认后删除）。
- Scenario: 勾选完成。
- Scenario: 批量操作非必需。

## Requirement: Plan CRUD

**R4**: 用户可以对行动计划本身做 CRUD。
- Scenario: 新建计划（弹窗输入标题/类型/描述/日期/优先级等）。
- Scenario: 编辑计划（弹窗）。
- Scenario: 删除计划（确认后软删除）。

## Requirement: AI Breakdown

**R5**: 用户可以从轻计划使用 AI 拆解为行动计划。
- Scenario: 在轻计划页点击"AI 拆解为行动计划"。
- Scenario: 弹窗输入开始日期/截止日期/每日可用时间。
- Scenario: 调用 DeepSeek 返回 JSON 任务列表。
- Scenario: 显示 AI 预览弹窗。
- Scenario: 用户确认后创建行动计划。
- Scenario: 非法 JSON 时显示错误 + 原始返回。

## Non-Goals

- 不做任务依赖关系（前置任务/后置任务）
- 不做甘特图的依赖线绘制
- 不做日历视图
- 不做任务提醒/通知
- 不做多用户协作
